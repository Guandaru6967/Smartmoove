﻿
using System;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;

namespace FaxPro.Views
{
    public partial class ShowPdf : ContentPage
    {
        string url;
        public ShowPdf(string pdfurl, string title)
        {
            try
            {
                InitializeComponent();

                //pdfView = new Components.PDFView
                //{
                //    IsEnabled = true,
                //    DeletePdf = false,
                //    IsPDF = true,
                //    HeightRequest = 1500,
                //    WidthRequest = 1000,
                //    VerticalOptions = LayoutOptions.FillAndExpand
                //};
                //#if DEBUG
                //            url = pdfurl.Replace("datadev", "data").ToString().Trim();
                //            pdfurl = url;
                //#endif
                BackgroundColor = Color.Transparent;
                Title = title;
                HeightRequest = 1000;
                WidthRequest = 1000;
                url = pdfurl;
                if (Device.RuntimePlatform == Device.Android)
                {
                    pdfView.Uri = url;
                    pdfView.On<Android>().EnableZoomControls(true);
                    pdfView.On<Android>().DisplayZoomControls(false);
                }

                else
                    pdfView.Uri = url;
            }
            catch (Exception ex)
            {

            }
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            App.FaxProAppData.HistoryPageVisited = "HistoryPdfView";
            pdfView.DeletePdf = true;

        }


    }
}
